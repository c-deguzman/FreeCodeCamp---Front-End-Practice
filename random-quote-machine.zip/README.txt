A Pen created at CodePen.io. You can find this one at http://codepen.io/c-deguzman/pen/Gmgwer.

 Free Code Camp - Random Quote Machine